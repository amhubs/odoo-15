<?php
// Text
$_['text_success']           = 'Success: You have read orders!';

// Error
$_['error_permission']       = 'Warning: You do not have permission to access the API!';

$_['text_product_not_updated']       = 'Warning: Issue updating the product';
$_['text_product_update_success']           = 'Success: %s!';

$_['text_order_not_updated']       = 'Warning: Issue updating the order';
$_['text_order_update_success']           = 'Success: %s!';
